import DAOCliente from '../DAO/DAOCliente'

export default
class UsuarioController {
    cliente: DAOCliente = new DAOCliente()
/*
    public findClient (id: number) {
      this.cliente.getAsyncCliente(1).then(res => {
        console.log(res)
      })
    }
    */
}
