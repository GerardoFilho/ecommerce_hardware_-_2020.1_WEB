
var cliente = {
  usuario: 'xXDanielXx',
  senha: 'yare yare daze',
  email: 'daze@live.com',
  nome: 'joestar',
  endereco: 'aqui',
  estado: 'Ceara',
  cidade: 'Quixada',
  cep: '63900000',
  cpf: 123456789
}

export default cliente
