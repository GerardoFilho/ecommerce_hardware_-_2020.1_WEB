import Usuario from './Usuario'

export default
class Administrador extends Usuario { // eslint-disable-line no-unused-vars
  // dao: DAOVendedor

/*
    public setNomeCompleto (nomeCompleto: DAOCLiente): void{
      this.nomeCompleto = nomeCompleto
    }

    public getdao (): DAOCLiente {
      return this.nomeCompleto
    }
*/
}
